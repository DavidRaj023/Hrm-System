DROP TABLE IF EXISTS employee;
DROP TYPE IF EXISTS gender;
DROP TYPE IF EXISTS marital;
DROP TYPE IF EXISTS employee_status;
DROP FUNCTION IF EXISTS set_updated_timestamp();

